M14hh.obj	head only
M14hh.obj	head and hair

texture
12c14c70	head
13932ef0	hair

use .ppm file, that's the correct format
you might need to remove ".ppm" from filename

http://www.office-converter.com/DDS-to-PPM